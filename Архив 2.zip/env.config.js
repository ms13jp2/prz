export const APP_CONFIG = {
  APP_URL: process.env.NEXT_PUBLIC_APP_URL || 'https://youigo.vercel.app',
  GLOBAL_DISCOUNT: process.env.NEXT_PUBLIC_GLOBAL_DISCOUNT || '0'
}; 